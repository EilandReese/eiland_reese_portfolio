require "application_system_test_case"

class BlogsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit blogs_url
  #
  #   assert_selector "h1", text: "Blog"
  # end
end
