require 'test_helper'

class TechnologyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
