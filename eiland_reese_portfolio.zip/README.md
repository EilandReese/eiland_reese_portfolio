# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

-Real time chat engine for blogs
-Blog
-Portfolio
-Drag and Drop Interface

### Code Example

```ruby
def my_great_method
    puts "here it is"
end
````

```javascript
alert('hi there')
````
